function sound(){
     var snd = new Audio('sigma_drive.mp3')
     snd.play()//plays the sound
}

